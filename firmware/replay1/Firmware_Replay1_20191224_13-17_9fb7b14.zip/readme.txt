Replay1 Firmware (20191224_13-17_9fb7b14)

To update your replay firmware via a USB cable connected to the USB header
pins or mini usb socket on the board, refer to the instructions at the top
of the usbUpdater/replay_update.bat or usbUpdater/replay_update.sh file.

To update your replay firmware via sdcard, transfer the contents of the
rAppUpdater/ folder to your sdcard, boot the replay, load the rApp ini
file most suitable to your display setup then follow the on screen instructions.
